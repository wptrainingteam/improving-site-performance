# Slides

If you wish to create slides using the team's official format, go to the [SHOWER.md](SHOWER.md) file for information on how to do that.

If you have created slides to use with this lesson plan using other formats (such as PowerPoint or Google Slides), please either provide a link to them within this README file or upload the files in this folder and mention it here. Adding your name and the date you used the slides is very helpful.

## Contributor Slide Resources

*
